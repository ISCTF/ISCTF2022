from secret import flag
from Crypto.Util.number import *

key = getPrime(16)
def encrypt(text):
	return [(((ord(i)<<4)&0xff) + ((ord(i)>>4)&0xff))^key for i in text]

lis = encrypt(flag)

for i in lis:
	p1 = getPrime(16)
	p2 = getPrime(16)
	print(p1,p2,i%p1,i%p2)